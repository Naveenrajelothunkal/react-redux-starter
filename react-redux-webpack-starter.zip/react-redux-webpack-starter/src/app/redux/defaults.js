const defaultData = {
  APP_NAME: 'React Starter',
  UI: {
    name: '',
    password: '',
    show:false
  }
};

export default defaultData;
