import React from 'react';
import {connect} from 'react-redux';
import './FirstComponent.scss';
import SecondComponent from './SecondComponent.js';
import AppStore from '../redux/store';
let global_store = {};
const FirstComponent = () => {

  return Object.assign({}, React.Component.prototype, {

    componentWillMount() {
      this.state = {
        name: "Naveen",
        password:"Naveen",
        show:false
      };
    },
     handleChange(e) {
       this.setState({ name: e.target.value });
    },
    handleChangepass(e) {
       this.setState({ password: e.target.value });
    },
    handleClick(e) {
      this.setState({
        show: true
      });
      debugger;
      let shouldExposeReduxTools = true;
      if(process.env.NODE_ENV === 'production') {
        shouldExposeReduxTools = false;
      }
       global_store = AppStore.create(shouldExposeReduxTools,{UI:this.state});
       console.log(global_store.getState().UI);
    },

    render() {
  if(this.state.show==false){
      return  <div className="container">
          <div className="form-horizontal col-md-4">
                  <label>Username:</label>
                  <input type="text" defaultValue={this.state.name} className="form-control" onChange={ (e) => { this.handleChange(e); } } />
                   <label>password:</label>
                   <input type="password" defaultValue={this.state.password} className="form-control" onChange={ (e) => { this.handleChangepass(e); } }/>
                   <br/>
                   <input type="button" value="submit" className="btn btn-primary" onClick={ (e) => { this.handleClick(e); } }/>
                </div>
              </div>;
      }else{
      return (
        <div>
         
          <SecondComponent loggedin={global_store.getState().UI}/>
        </div>
      );
      
      }
                
    }

  });

};

FirstComponent.propTypes = {
  
};

const mapStateToProps = (state) => {
 console.log(state);
  return {
    UI: state.UI
  };
};

FirstComponent.propTypes = {
  UI: React.PropTypes.object
};

FirstComponent.contextTypes = {
  store: React.PropTypes.object
};

export default connect(mapStateToProps)(FirstComponent);
