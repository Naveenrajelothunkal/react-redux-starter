
 import React from 'react';


const SecondComponent = () => {

  return Object.assign({}, React.Component.prototype, {

    componentWillMount() {
      
    },
    componentDidMount() {
 		
    },
    
    render() {

      const {loggedin} = this.props;
      return (
  	  <div>
  	  <p>name:{loggedin.name}</p>
  	  <p>password:{loggedin.password}</p>

  	  </div>
      )          
    }

  });

};

SecondComponent.propTypes = {
  loggedin: React.PropTypes.object.isRequired
};

export default SecondComponent;
